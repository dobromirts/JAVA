package wildFarm;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String input = scanner.nextLine();

        while (!input.equals("End")) {
            String[] animalInformation = input.split("\\s+");
            String[] foodInformation = scanner.nextLine().split("\\s+");


            Animal animal=null;
            Food food=null;
            switch (foodInformation[0]) {
                case "Vegetable":
                    food = new Vegetable(Integer.parseInt(foodInformation[1]));
                    break;
                case "Meat":
                    food = new Meat(Integer.parseInt(foodInformation[1]));
                    break;

            }
            switch (animalInformation[0]) {
                case "Cat":
                    Cat cat= new Cat(animalInformation[0], animalInformation[1],
                            Double.parseDouble(animalInformation[2]), animalInformation[3], animalInformation[4]);
                    cat.makeSound();
                    cat.eatFood(food);
                    System.out.println(cat.toString());

                    break;
                case "Mouse":
                    Mouse mouse = new Mouse(animalInformation[0], animalInformation[1],
                            Double.parseDouble(animalInformation[2]), animalInformation[3]);
                    mouse.makeSound();
                    mouse.eatFood(food);
                    System.out.println(mouse.toString());
                    break;
                case "Zebra":
                    Zebra zebra = new Zebra(animalInformation[0], animalInformation[1],
                            Double.parseDouble(animalInformation[2]), animalInformation[3]);
                    zebra.makeSound();
                    zebra.eatFood(food);
                    System.out.println(zebra.toString());
                    break;
                case "Tiger":
                    Tiger tiger = new Tiger(animalInformation[0], animalInformation[1],
                            Double.parseDouble(animalInformation[2]), animalInformation[3]);
                    tiger.makeSound();
                    tiger.eatFood(food);
                    System.out.println(tiger.toString());
                    break;
            }



            input = scanner.nextLine();
        }
    }
}
