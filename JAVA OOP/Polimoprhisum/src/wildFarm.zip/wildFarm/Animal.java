package wildFarm;

public interface Animal {
    void makeSound();
    void eatFood(Food food);
}
