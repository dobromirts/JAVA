package vechicles;

public interface Vechicle {

   String drive(double distance);
   void refuel(double liters);
}
