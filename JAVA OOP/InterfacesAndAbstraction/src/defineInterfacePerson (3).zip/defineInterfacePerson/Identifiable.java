package defineInterfacePerson;

public interface Identifiable extends Birthable {
    String getId();
}
