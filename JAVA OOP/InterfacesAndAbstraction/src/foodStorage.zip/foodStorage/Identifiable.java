package foodStorage;

public interface Identifiable {
    String getId();
}
