package defineInterfacePerson;

public interface Birthable {
    String getId();
}
