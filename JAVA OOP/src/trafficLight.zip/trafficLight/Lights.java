package trafficLight;

public enum  Lights {
    RED,
    GREEN,
    YELLOW,
}
