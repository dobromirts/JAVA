package kingsGambit;

public interface Defender {
    String respondToAttack();
}
