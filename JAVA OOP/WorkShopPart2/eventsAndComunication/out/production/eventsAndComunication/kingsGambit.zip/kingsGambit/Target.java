package kingsGambit;

public interface Target {

    void onAttacked();
}
