package Listener;

public interface NameChangeListener {
    void handleOnNameChange(Even even);
}
