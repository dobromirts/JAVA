public class GoldenEditionBook extends Book {
    private String title;
    private String author;
    private double price;

    public GoldenEditionBook(String title, String author, double price) {
        super(title, author, price+price*0.3);
    }


    @Override
    public double getPrice() {
        return super.getPrice();
    }


}
