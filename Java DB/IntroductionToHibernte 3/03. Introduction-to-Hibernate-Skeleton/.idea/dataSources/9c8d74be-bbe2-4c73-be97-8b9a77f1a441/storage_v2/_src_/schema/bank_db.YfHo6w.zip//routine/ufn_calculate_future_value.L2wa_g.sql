create function ufn_calculate_future_value(init_sum double, yearly_interest_rate double, num_year int)
  returns double
  begin
 declare result double;
 set result:=round(init_sum*(pow(1+yearly_interest_rate,num_year)),2);
 return result;
 end;

