create procedure usp_get_holders_with_balance_higher_than(IN example decimal)
  begin
select ah.first_name,ah.last_name
from account_holders as `ah`
join accounts as `a`
on `a`.id=`ah`.id
where a.balance>example
order by ah.id;
end;

