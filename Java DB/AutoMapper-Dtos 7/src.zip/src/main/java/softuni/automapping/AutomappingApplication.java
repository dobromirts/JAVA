package softuni.automapping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutomappingApplication {

    public static void main(String[] args) {
        SpringApplication.run(AutomappingApplication.class, args);
    }

}
