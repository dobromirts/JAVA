package softuni.automapping.domain.entities;

public enum Role {
    ADMIN,USER
}
