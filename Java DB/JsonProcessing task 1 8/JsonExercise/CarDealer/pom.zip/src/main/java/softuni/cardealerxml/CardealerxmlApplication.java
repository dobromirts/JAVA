package softuni.cardealerxml;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CardealerxmlApplication {

    public static void main(String[] args) {
        SpringApplication.run(CardealerxmlApplication.class, args);
    }

}
