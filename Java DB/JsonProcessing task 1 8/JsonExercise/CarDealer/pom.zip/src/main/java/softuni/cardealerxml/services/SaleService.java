package softuni.cardealerxml.services;

public interface SaleService {
    void seedSales();
}
