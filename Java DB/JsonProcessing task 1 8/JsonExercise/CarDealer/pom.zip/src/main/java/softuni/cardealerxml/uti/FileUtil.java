package softuni.cardealerxml.uti;

import java.io.FileNotFoundException;
import java.io.IOException;

public interface FileUtil {
    String getContent(String path) throws IOException;
}
