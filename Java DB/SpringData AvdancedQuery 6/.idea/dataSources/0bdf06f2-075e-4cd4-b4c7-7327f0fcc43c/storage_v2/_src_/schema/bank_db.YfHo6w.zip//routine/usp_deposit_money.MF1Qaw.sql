create procedure usp_deposit_money(IN account_id int, IN money_amount decimal(10, 4))
  BEGIN
START TRANSACTION;
CASE WHEN money_amount <= 0 or money_amount IS NULL OR account_id IS NULL OR account_id<1
THEN ROLLBACK;
ELSE 
UPDATE accounts as a 
SET a.balance = a.balance + money_amount
WHERE a.id = account_id;
END CASE;
COMMIT;
END;

