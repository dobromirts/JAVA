package bookshopsystemapp.domain.entities;

public enum AgeRestriction {

    MINOR, TEEN, ADULT
}
