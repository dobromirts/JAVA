package softuni.jsonexercise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JsonexerciseApplication {

    public static void main(String[] args) {
        SpringApplication.run(JsonexerciseApplication.class, args);
    }

}
