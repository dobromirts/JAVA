package listLterator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);

        ArrayList<String>input=Arrays.stream(scanner.nextLine().split(" ")).skip(1).collect(Collectors.toCollection(ArrayList::new));
        ListIterator listIterator=new ListIterator(input);

        String line=scanner.nextLine();
        while (!line.equals("END")){
            switch (line){
                case "Move":
                    System.out.println(listIterator.move());
                    break;
                case "HasNext":
                    System.out.println(listIterator.hasNext());
                    break;
                case "Print":
                    try {
                        System.out.println(listIterator.print());
                    }catch (Exception e){
                        System.out.println(e.getMessage());
                    }
                    break;
                case "PrintAll":
                    for (String s : listIterator) {
                        System.out.print(s+" ");
                    }
                    System.out.println();
                    break;
            }

            line=scanner.nextLine();
        }

    }
}
