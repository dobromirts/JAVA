package listLterator;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ListIterator implements Iterable<String> {
    private static final int INIT_INDEX=0;
    private List<String> elements;
    private int index;

    public ListIterator(ArrayList<String>data) {
        this.elements = data;
        this.setIndex();
    }
    private void setIndex(){
        if (this.elements.size()==0){
            this.index=INIT_INDEX;
        }else {
            this.index=0;
        }
    }

    public boolean move(){
        if (this.index<elements.size()-1){
            this.index++;
            return true;
        }
        return false;

    }
    public boolean hasNext(){
        if (this.index<elements.size()-1){
            return true;
        }
        return false;
    }

    public String print(){
        if (this.elements.size()==0){
            throw new IndexOutOfBoundsException("Invalid Operation!");
        }
        return elements.get(this.index);
    }
    public void printAll(){

    }

    @Override
    public Iterator<String> iterator() {
        return this.elements.listIterator();
    }
}
