package comparingObjects;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        List<Person>people=new ArrayList<>();

        String input=scanner.nextLine();
        while (!input.equals("END")){
            String []tokens=input.split(" ");
            Person person=new Person(tokens[0],Integer.parseInt(tokens[1]),tokens[2]);
            people.add(person);

            input=scanner.nextLine();
        }

        int n=Integer.parseInt(scanner.nextLine());

        Person comparePerson=people.get(n-1);
        int equalPeople=(int)people.stream().filter(p->p.compareTo(comparePerson)==0).count();

        if (equalPeople==1){
            System.out.println("No matches");
        }else {
            System.out.printf("%d %d %d",equalPeople,people.size()-equalPeople,people.size());
        }

    }
}
