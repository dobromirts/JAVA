package rawdata;

public class Tire {
    private double presure;

    public Tire(double presure) {
        this.presure = presure;
    }
    public Double getPresure(){
        return this.presure;
    }
}
